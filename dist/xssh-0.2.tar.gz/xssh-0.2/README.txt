===========
XSSH
===========

XSSH Multiplexer is a tool to run shell commands on one or more Unix hosts
Currently it does not support input from command line for host names
you have to use an infile, the format of the infile is one host per line
I plan on adding more features to this, feel free to fork and do the same
License for this file is the same as for the other stuff in my Git repo
Apache License Version 2.0 January 2013

